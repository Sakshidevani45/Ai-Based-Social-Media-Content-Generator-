from flask import Flask, render_template, request, redirect, url_for
import database
import ai_generator

# Initialize the Flask application
app = Flask(__name__)

# Route for the home page (Interface)
@app.route("/", methods=["GET", "POST"])
def index():
    generated_content = None
    
    if request.method == "POST":
        # Get data from the form
        platform = request.form.get("platform")
        topic = request.form.get("topic")
        tone = request.form.get("tone")
        
        # Ensure all fields are filled
        if platform and topic and tone:
            # Generate content using AI logic
            content = ai_generator.generate_content(platform, topic, tone)
            
            # Save to database
            database.add_generated_content(
                platform, 
                topic, 
                tone, 
                content['caption'], 
                content['hashtags'], 
                content['ideas']
            )
            
            # Prepare content to display
            generated_content = content
    
    # Retrieve history from database
    history = database.get_all_content()
    
    return render_template("index.html", generated_content=generated_content, history=history)

if __name__ == "__main__":
    # Initialize database tables before running app
    database.init_db()
    # Run the web server
    app.run(debug=True)
