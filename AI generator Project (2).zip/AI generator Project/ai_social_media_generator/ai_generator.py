import random
import os
import google.generativeai as genai

HASHTAG_EXTRAS = ["#Trending", "#Explore", "#DailyContent", "#SocialMedia", "#Inspiration"]

def generate_caption(platform, topic, tone):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return "Error: GEMINI_API_KEY not found. Please set it in your environment."
    
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-pro')
        
        prompt = (f"Generate a creative social media caption for the topic '{topic}' "
                  f"with a {tone} tone. The caption should be suitable for {platform}. "
                  f"Make it feel human, creative, and non-robotic. Do not use hashtags.")
        
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Error generating caption: {str(e)}"

def generate_hashtags(topic):
    words = topic.lower().split()
    hashtags = [f"#{word.capitalize()}" for word in words]

    hashtags.extend(random.sample(HASHTAG_EXTRAS, 2))
    return " ".join(set(hashtags))

def generate_ideas(topic):
    ideas = [
        f"Behind the scenes of {topic}",
        f"Top mistakes people make with {topic}",
        f"Why {topic} is trending right now",
        f"Beginner’s guide to {topic}",
        f"Myths vs facts about {topic}"
    ]
    return "\n".join(random.sample(ideas, 3))

def generate_content(platform, topic, tone):
    caption = generate_caption(platform, topic, tone)
    hashtags = generate_hashtags(topic)
    ideas = generate_ideas(topic)

    return {
        "caption": caption,
        "hashtags": hashtags,
        "ideas": ideas
    }
