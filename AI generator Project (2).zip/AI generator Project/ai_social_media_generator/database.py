import sqlite3

# Define the database name
DB_NAME = "social_media.db"

def init_db():
    """
    Initialize the database.
    Creates the 'posts' table if it does not already exist.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Create table for storing generated content
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            topic TEXT NOT NULL,
            tone TEXT NOT NULL,
            caption TEXT NOT NULL,
            hashtags TEXT NOT NULL,
            ideas TEXT NOT NULL
        )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully.")

def add_generated_content(platform, topic, tone, caption, hashtags, ideas):
    """
    Save generated content to the database.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO posts (platform, topic, tone, caption, hashtags, ideas)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (platform, topic, tone, caption, hashtags, ideas))
    
    conn.commit()
    conn.close()

def get_all_content():
    """
    Retrieve all stored content from the database.
    Returns a list of tuples.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM posts ORDER BY id DESC')
    rows = cursor.fetchall()
    
    conn.close()
    return rows

if __name__ == "__main__":
    init_db()
